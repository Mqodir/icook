
this.colors = {"active" : "#ffad71",
				"selected" : "#ffdabd",
               	"inactive" : "#ff7000"};


this.colorsCatrgory = {"active" : "#ffdabd",
               		"inactive" : "#fff6ef"};

this.colorsSearch = {"active" : "#ffffff",
               "inactive" : "#fff6ef"};

this.colorsSearchBorder = {"active" : "#555555",
               "inactive" : "#fff6ef"};

this.poster = {"width"  : 172,
               "height" : 264};

this.itemTop = {"width"  : 220,
               "height" : 240};


this.borderSearch = {"active"  : 1,
               "inactive" : 0};

this.menuWidth = 256;

this.inactiveOpacity = 0.8;

this.animationDuration = 150;

this.margin = 60;

this.defaultPoster = "apps/icook/resources/icon200.png";


this.itemViewInfo = "Значение приведено для диеты, основанной на 2500 ккал/сутки.";
